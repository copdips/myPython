This directory contains the code to run the music perception and imagination
experiment using PsychToolbox within Matlab (tested on Matlab 2014a / Mac OS X
10.10).
