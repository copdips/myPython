This directory contains various helper scripts.

-   eeglab: scripts to convert the raw data and import it into EEGLab