#!/bin/sh

ln -s ../full.v2/S03_Jingle\ Bells_lyrics.wav S03_Jingle\ Bells_lyrics.wav
ln -s ../full.v2/S04_Mary\ Had\ A\ Little\ Lamb_lyrics.wav S04_Mary\ Had\ A\ Little\ Lamb_lyrics.wav
ln -s ../full.v2/S13_Jingle\ Bells_no\ lyrics.wav S13_Jingle\ Bells_no\ lyrics.wav
ln -s ../full.v2/S14_Mary\ Had\ A\ Little\ Lamb_no\ lyrics.wav S14_Mary\ Had\ A\ Little\ Lamb_no\ lyrics.wav 
ln -s ../full.v2/S21_EmperorWaltz.wav S21_EmperorWaltz.wav
ln -s ../full.v2/S23_Star\ Wars\ Theme.wav S23_Star\ Wars\ Theme.wav
ln -s ../full.v2/S24_Eine\ kleine\ Nachtmusic.wav S24_Eine\ kleine\ Nachtmusic.wav