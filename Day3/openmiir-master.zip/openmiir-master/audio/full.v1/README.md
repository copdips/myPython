Run makelinks.sh or copy the missing files from ../full.v2

*Please note:*
These short stimulus clips are shared under fair use intention to allow reproduction of the EEG study and musical analysis of the audio signals.
Anyone using them should ensure that their use conforms with the copyright laws in the jurisdiction in which they are working.