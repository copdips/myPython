Run makelinks.sh or copy the missing files from ../cues.v2
