#!/bin/sh

ln -s ../cues.v2/S03_Jingle\ Bells_lyrics_cue.wav S03_Jingle\ Bells_lyrics_cue.wav
ln -s ../cues.v2/S04_Mary\ Had\ A\ Little\ Lamb_lyrics_cue.wav S04_Mary\ Had\ A\ Little\ Lamb_lyrics_cue.wav
ln -s ../cues.v2/S13_Jingle\ Bells_no\ lyrics_cue.wav S13_Jingle\ Bells_no\ lyrics_cue.wav
ln -s ../cues.v2/S14_Mary\ Had\ A\ Little\ Lamb_no\ lyrics_cue.wav S14_Mary\ Had\ A\ Little\ Lamb_no\ lyrics_cue.wav 
ln -s ../cues.v2/S21_EmperorWaltz_cue.wav S21_EmperorWaltz_cue.wav
ln -s ../cues.v2/S23_Star\ Wars\ Theme_cue.wav S23_Star\ Wars\ Theme_cue.wav
ln -s ../cues.v2/S24_Eine\ kleine\ Nachtmusic_cue.wav S24_Eine\ kleine\ Nachtmusic_cue.wav