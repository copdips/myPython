This directory contains the audio stimuli and cues.

-   cues.v1 - version 1 of the cue clicks (P01-P08)

-   cues.v2 - version 2 of the cue clicks (P09-P14)

-   full.v1 - version 1 of the full stimuli including cue clicks (P01-P08)

-   full.v2 - version 2 of the full stimuli including cue clicks (P09-P14)