This directory contains optional exported datasets for use with
[pylearn2](<https://github.com/lisa-lab/pylearn2/>) / [deepthought](<https://github.com/sstober/deepthought>).
