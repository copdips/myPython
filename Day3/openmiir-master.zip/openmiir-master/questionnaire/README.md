This directory contains the questionnaire and the respective data collected from the participants.

* Questionnaire.pdf - (empty) questionnaire. Page 1 and 2 were filled out by participants, page 3 was filled out by the researcher.
* QuestionnaireScores.xls - scores and demographic information from the questionnaire for all participants.