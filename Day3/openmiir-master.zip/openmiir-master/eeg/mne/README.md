This directory contains the raw EEG files in the FIF format used by MNE.

Please place the following raw EEG files here:

P01-raw.fif  
P04-raw.fif  
P05-raw.fif  
P06-raw.fif  
P07-raw.fif  
P09-raw.fif  
P11-raw.fif  
P12-raw.fif  
P13-raw.fif  
P14-raw.fif

Instructions on where and how these files can be downloaded can be found at
<https://github.com/sstober/openmiir>
