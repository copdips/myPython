"""
bla bla bla
"""
def f(a, c, b):
    """ f : calcul simple
    a : acceleration, b : resistance, c : vitesse
        """
    return (a*b+c,a/b)




